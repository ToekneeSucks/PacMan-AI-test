import javax.swing.ImageIcon;

//This class imports the images and create image icons to store them
public class Icons {
	
	//making image icons to store different objects on the board
	public static final ImageIcon WALL = new ImageIcon("images/Wall.bmp");
	public static final ImageIcon FOOD = new ImageIcon("images/Food.bmp");
	public static final ImageIcon BLANK = new ImageIcon("images/Black.bmp");
	public static final ImageIcon DOOR = new ImageIcon("images/Black.bmp");
	public static final ImageIcon SKULL = new ImageIcon("images/Skull.bmp");

	//Store the PacMan animations in an image icon array
	public static final ImageIcon[] PACMAN = {
			
			new ImageIcon("images/PacMan0.gif"),
			new ImageIcon("images/PacMan1.gif"),
			new ImageIcon("images/PacMan2.gif"),
			new ImageIcon("images/PacMan3.gif"),
			
	};
	
	//Store the images of ghosts in an image icon array
	public static final ImageIcon[] GHOST = {
			
			new ImageIcon("images/Ghost0.bmp"),
			new ImageIcon("images/Ghost1.bmp"),
			new ImageIcon("images/Ghost2.bmp"),
			
			
	};
	
}
