import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.*;
import java.util.Scanner;
import javax.swing.*;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.ArrayList;

@SuppressWarnings("serial")

//This class sets up the game board of PacMan
public class Board extends JPanel implements KeyListener, ActionListener {

	// Set a timer for the game
	private Timer gameTimer = new Timer(250, this);

	// Creating a 2D array that stores the information about the maze
	private Cell[][] mazeArray = new Cell[25][27];

	// Using the class mover to set up a PacMan character
	private Mover pacMan;

	// Creating an array to store the locations of the ghosts
	private Mover[] ghostArray = new Mover[3];

	// Create a variable to store the number of pellets
	private int pellets = 0;

	// Create a variable to store the score
	private int score = 0;

	private int initialMovement = 0;

	// This method is the constructor that builds the entire board
	public Board() {

		// Customizing the dimensions and backgrounds of the board
		setLayout(new GridLayout(25, 27));
		setBackground(Color.BLACK);

		loadBoard();

	}

	// This method transfers the information from the text file to set up the board
	private void loadBoard() {

		int row = 0;

		Scanner inputFile;

		try {

			// Using the scanner variable to read the maze text file
			inputFile = new Scanner(new File("maze.txt"));

			// Using a while loop to constantly check if there are more lines in the text
			// file
			while (inputFile.hasNext()) {

				// Creating a char array to store the characters of each line
				char[] lineArray = inputFile.nextLine().toCharArray();

				// Creating a for loop to manage the information of each column and add it to
				// the board
				for (int column = 0; column < lineArray.length; column++) {

					// Storing each line of the maze from the characters of the lineArray to the
					// cells of the mazeArray
					mazeArray[row][column] = new Cell(lineArray[column], 0);

					// If the text file reads the character 'F', the number of pellets increments
					if (lineArray[column] == 'F')
						pellets++;

					// if the character is 'P', then the location of PacMan will be set at this
					// coordinate
					else if (lineArray[column] == 'P') {

						pacMan = new Mover(row, column, 0, 0);
						pacMan.setIcon(Icons.PACMAN[0]);
						pacMan.setDirection(0);

					}

					// Check if the characters in the textfile represents one of the ghosts
					else if (lineArray[column] == '0' || lineArray[column] == '1' || lineArray[column] == '2') {

						int gNum = Character.getNumericValue(mazeArray[row][column].getItem());
						ghostArray[gNum] = new Mover(row, column, 0, 0);
						ghostArray[gNum].setIcon(Icons.GHOST[gNum]);

					}

					// adding the line of cells to the board
					add(mazeArray[row][column]);

				}

				// Moving on to the next row by incrementing
				row++;

			}

			// closing the access to the text file
			inputFile.close();

			// Catch any errors that might occur during this process
		} catch (FileNotFoundException error) {

			System.out.println("File not found");

		}

	}

	// This method detects if a key is pressed during the game
	public void keyPressed(KeyEvent key) {

		// If the timer has not run and pacMan is alive, the timer starts
		if (gameTimer.isRunning() == false && pacMan.isDead() == false)
			gameTimer.start();

		// If the PacMan is still alive and there are still pellets on the board
		else if (pacMan.isDead() == false && score != pellets) {

			// This variable determines which character is pressed using the ASCII code of
			// the pressed key
			int direction = key.getKeyCode() - 37;

			// Creating the variables to store the change in row and column positions
			int dRow = 0;
			int dCol = 0;

			// Finding the movement of the PacMan depending on the direction
			if (direction == 0)
				dCol = -1;
			else if (direction == 1)
				dRow = -1;
			else if (direction == 2)
				dCol = 1;
			else if (direction == 3)
				dRow = 1;

			// If the new position of the PacMan is not a wall, then the direction is set
			if (mazeArray[pacMan.getRow() + dRow][pacMan.getColumn() + dCol].getIcon() != Icons.WALL) {

				pacMan.setIcon(Icons.PACMAN[direction]);
				pacMan.setDirection(direction);

			}

		}

	}

	// This method detects if a key is released
	public void keyReleased(KeyEvent key) {

		// Not used

	}

	// This method detects if a key is typed
	public void keyTyped(KeyEvent key) {

		// Not used

	}

	// This method executes the movement of the PacMan
	private void performMove(Mover mover) {

		// Determine the current cell position and the future cell position
		Cell currentCell = mazeArray[mover.getRow()][mover.getColumn()];
		Cell nextCell = mazeArray[mover.getNextRow()][mover.getNextColumn()];

		// Teleport PacMan through the doors
		if (mover.getColumn() == 1) {

			mover.setColumn(25);
			mazeArray[12][1].setIcon(Icons.DOOR);

		} else if (mover.getColumn() == 25) {

			mover.setColumn(1);
			mazeArray[12][25].setIcon(Icons.DOOR);

		}

		// Make sure the next cell is not a wall
		if (nextCell.getIcon() != Icons.WALL) {

			// If the ghosts travel over the food, the food gets back onto the board
			if (mover != pacMan && currentCell.getItem() == 'F')
				currentCell.setIcon(Icons.FOOD);

			// Otherwise the cell it is leaving will be blank
			else
				currentCell.setIcon(Icons.BLANK);

			if (currentCell.getItem() == 'D') {

				if (mover.getColumn() == 0)
					mover.setDirection(0);

				else
					mover.setDirection(2);

			}

			// Move the character
			mover.move();
			currentCell = mazeArray[mover.getRow()][mover.getColumn()];

			if (collided())
				death();

			else
				// Changing the appearance of the current cell
				currentCell.setIcon(mover.getIcon());

			// If PacMan goes to a cell that has food, the score increments
			if (mover == pacMan && nextCell.getItem() == 'F') {

				// Incrementing the score and setting the current cell empty
				score++;
				currentCell.setItem('E');

				// If all the pellets have been eaten, the game ends
				if (score == pellets) {

					gameTimer.stop();
					JOptionPane.showMessageDialog(this, "You cleared the board!");

				}

			}
		}

	}

	// This method gets the ghost out of the spawn immediately
	private void getOutSpawn() {

		if (initialMovement == 0) {

			ghostArray[0].setDirection(2);
			performMove(ghostArray[0]);

			ghostArray[1].setDirection(0);
			performMove(ghostArray[1]);

			ghostArray[2].setDirection(1);
			performMove(ghostArray[2]);

			initialMovement++;

		}

		else if (initialMovement == 1) {

			performMove(ghostArray[0]);

			performMove(ghostArray[1]);

			performMove(ghostArray[2]);

			initialMovement++;

		}

		else if (initialMovement == 2) {

			ghostArray[0].setDirection(1);
			performMove(ghostArray[0]);

			ghostArray[1].setDirection(1);
			performMove(ghostArray[1]);

			performMove(ghostArray[2]);

			initialMovement++;

		}

		else if (initialMovement == 3) {

			performMove(ghostArray[0]);

			performMove(ghostArray[1]);

			performMove(ghostArray[2]);

			initialMovement++;

		}

		else if (initialMovement == 4) {

			performMove(ghostArray[0]);

			ghostArray[1].setDirection(2);
			performMove(ghostArray[1]);

			performMove(ghostArray[2]);

			initialMovement++;

		}

		else if (initialMovement == 5) {

			ghostArray[0].setDirection(0);
			performMove(ghostArray[0]);

			ghostArray[2].setDirection(0);
			performMove(ghostArray[2]);

			initialMovement++;

		}

		else {

			performMove(ghostArray[2]);

			mazeArray[10][13].setIcon(Icons.WALL);

			initialMovement++;

		}

	}

	// This method detects if PacMan collided with the ghosts
	private boolean collided() {

		// Going through the ghostArray to check the locations of the ghosts
		for (Mover ghost : ghostArray) {

			// check if the location of PacMan is the same as the location of one of the
			// ghosts
			if (ghost.getRow() == pacMan.getRow() && ghost.getColumn() == pacMan.getColumn())
				return true;

		}

		// If Pac Man has not collided, then return false
		return false;

	}

	// This method is called when PacMan dies and it will end the game
	private void death() {

		// Change the status of PacMan to dead
		pacMan.setDead(true);

		// Change the icon of PacMan to a skull
		mazeArray[pacMan.getRow()][pacMan.getColumn()].setIcon(Icons.SKULL);

		// Stop the timer and the game once PacMan is dead
		gameTimer.stop();
		JOptionPane.showMessageDialog(this, "GAME OVER");

	}

	// This method moves the ghosts during the game
	private void moveGhosts() {

	    if (!pacMan.isDead()) {

	        for (Mover ghost : ghostArray) {

	            Mover currentNode = new Mover(ghost.getRow(), ghost.getColumn(), 0, 0);

	            // Use HashSets to track open and closed nodes
	            HashSet<Mover> openNodes = new HashSet<>();
	            HashSet<Mover> closedNodes = new HashSet<>();

	            closedNodes.add(currentNode);

	            // A* algorithm to find the path
	            while (currentNode.getRow() != pacMan.getRow() || currentNode.getColumn() != pacMan.getColumn()) {

	                // Generate neighboring nodes
	                int[][] directions = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
	                for (int[] dir : directions) {
	                    Mover neighbor = new Mover(currentNode.getRow() + dir[0], currentNode.getColumn() + dir[1], 0, 0);

	                    // Skip walls and ghosts
	                    if (mazeArray[neighbor.getRow()][neighbor.getColumn()].getIcon() == Icons.WALL) continue;

	                    // Skip nodes already closed
	                    if (closedNodes.contains(neighbor)) continue;

	                    // Calculate costs for the neighbor
	                    int gCost = Math.abs(neighbor.getRow() - ghost.getRow()) + Math.abs(neighbor.getColumn() - ghost.getColumn());
	                    int hCost = Math.abs(neighbor.getRow() - pacMan.getRow()) + Math.abs(neighbor.getColumn() - pacMan.getColumn());
	                    neighbor.setHCost(hCost);
	                    neighbor.setCost(gCost + hCost);

	                    openNodes.add(neighbor);
	                }

	                // If no valid moves, break out
	                if (openNodes.isEmpty()) break;

	                // Choose the node with the lowest total cost (tie-breaker on heuristic cost)
	                currentNode = openNodes.stream()
	                        .min(Comparator.comparingInt(Mover::getCost).thenComparingInt(Mover::getHCost))
	                        .orElse(null);

	                // Add currentNode to closed set and remove from open set
	                openNodes.remove(currentNode);
	                closedNodes.add(currentNode);
	            }

	            // Retrace the path to set the ghost's direction
	            if (currentNode != null) {
	                Mover pathNode = currentNode;
	                while (pathNode.getRow() != ghost.getRow() || pathNode.getColumn() != ghost.getColumn()) {

	                    // Find the next step in the path
	                    int rowDiff = pathNode.getRow() - ghost.getRow();
	                    int colDiff = pathNode.getColumn() - ghost.getColumn();

	                    if (rowDiff == 1 && colDiff == 0) ghost.setDirection(3); // Down
	                    else if (rowDiff == -1 && colDiff == 0) ghost.setDirection(1); // Up
	                    else if (rowDiff == 0 && colDiff == 1) ghost.setDirection(2); // Right
	                    else if (rowDiff == 0 && colDiff == -1) ghost.setDirection(0); // Left

	                    // Move the ghost in the chosen direction
	                    performMove(ghost);
	                }
	            }
	        }
	    }
	}

	// set the new direction for the ghosts
	// ghost.setDirection(dir);

	// If the PacMan is still alive, the ghosts continue to move

	// This method detects if the timer is still running
	public void actionPerformed(ActionEvent event) {

		// If the game timer is still running, continue to move PacMan
		if (event.getSource() == gameTimer) {

			performMove(pacMan);

			if (initialMovement < 7)
				getOutSpawn();
			else
				moveGhosts();

		}

	}

}
