import javax.swing.JLabel;

@SuppressWarnings("serial")

//This class creates the visuals of the game board
public class Cell extends JLabel{
	
	//Creating a variable to track each character in the text file
	private char item;
	

	//This method is the constructor method that keeps track of the "items" field
	public Cell(char item, int cost) {
		
		super();
		this.item = item;
		
		//This method call the utility method "setCodeIcon"
		setCodeIcon();
		
	}

	//Creating the getters and setters for the "item" field
	public char getItem() {
		return item;
	}

	public void setItem(char item) {
		this.item = item;
	}
	
	
	//This method performs the action of setting up the visuals of the board
	private void setCodeIcon() {
		
		if (item == 'P')
			setIcon(Icons.PACMAN[0]);
		else if (item == '0')
			setIcon(Icons.GHOST[0]);
		else if (item == '1')
			setIcon(Icons.GHOST[1]);
		else if (item == '2')
			setIcon(Icons.GHOST[2]);
		else if (item == 'W')
			setIcon(Icons.WALL);
		else if (item == 'D')
			setIcon(Icons.DOOR);
		else if (item == 'F')
			setIcon(Icons.FOOD);
		
		
	}
	
}
