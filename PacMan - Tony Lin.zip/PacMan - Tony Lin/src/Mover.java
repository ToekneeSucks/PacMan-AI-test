import javax.swing.JLabel;

//This class executes the movement of PacMan
public class Mover extends JLabel{
	
	//creating fields to store the row and column location
	private int row;
	private int column;
	
	//creating fields to store the change in row and column location
	private int dRow;
	private int dColumn;
	
	private int cost;
	private int hCost;
	
	//Creating a boolean variable to check if PacMan is dead,
	//or check when the ghosts become edible
	private boolean isDead;

	//Creating the constructor for row and column fields
	public Mover(int row, int column, int cost, int hCost) {
		super();
		this.row = row;
		this.column = column;
		this.cost = cost;
		this.hCost = hCost;
		
	}

	//Creating the getters and setters for each field 
	public int getRow() {
		return row;
	}

	public void setRow(int row) {
		this.row = row;
	}

	public int getColumn() {
		return column;
	}

	public void setColumn(int column) {
		this.column = column;
	}

	public int getdRow() {
		return dRow;
	}

	public void setdRow(int dRow) {
		this.dRow = dRow;
	}

	public int getdColumn() {
		return dColumn;
	}

	public void setdColumn(int dColumn) {
		this.dColumn = dColumn;
	}
	
	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}
	
	public int getHCost() {
		return hCost;
	}

	public void setHCost(int hCost) {
		this.hCost = hCost;
	}

	public boolean isDead() {
		return isDead;
	}

	public void setDead(boolean isDead) {
		this.isDead = isDead;
	}
	
	//This utility method moves PacMan depending on the change in row and column
	public void move() {
		
		row += dRow;
		column += dColumn;
		
	}
	
	//This method takes the direction and update the change in row and column
	public void setDirection(int direction) {
		
		//Reset the change in row and column to 0
		dRow = 0;
		dColumn = 0;
		
		//Depending on the direction, update the change in location
		if (direction == 0)
			dColumn = -1;
		else if (direction == 1)
			dRow = -1;
		else if (direction == 2)
			dColumn = 1;
		else if (direction == 3)
			dRow = 1;
		
		
	}
	
	//This method receives the change in location and determine the new direction
	public int getDirection() {
		
		//Check the change in row and column to find the new direction
		if (dRow == 0 && dColumn == -1)
			return 0;
		else if (dRow == -1 && dColumn == 1)
			return 2;
		else
			return 3;
		
	}
	
	//This method gets the next row location depending on the current location and the
	//change in location
	public int getNextRow() {
		
		return row + dRow;
		
	}
	
	//This method gets the next column location depending on the current location and the
	//change in location
	public int getNextColumn() {
		
		return column + dColumn;
		
	}

}
