
//Project Header

//Additional Features: 

//This class is the application class that runs the GUI of the PacMan Game
public class PacManGame {

	//This method calls the PacManGUI
	public static void main(String[] args) {
		
		//This line calls the constructor method of the PacManGUI 
		new PacManGUI();

	}

}
