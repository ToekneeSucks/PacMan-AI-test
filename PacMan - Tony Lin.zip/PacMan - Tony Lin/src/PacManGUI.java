import javax.swing.*;

@SuppressWarnings("serial")

//This class sets up the GUI frame of the PacMan game

public class PacManGUI extends JFrame{
	
	//Calls the constructor method of the game board
	private Board board = new Board();
	
	//This method is the constructor that adds all of the objects to the frame
	public PacManGUI() {
		
		//Customizes dimensions and title of the frame
		setSize(600, 600);
		setTitle("Tony Lin' PacMan Game");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//Adding the board to the frame
		add(board);
		
		//Enabling a keyListener to detect key presses
		addKeyListener(board);
		
		//making the frame visible
		setVisible(true);
		
	}
}
